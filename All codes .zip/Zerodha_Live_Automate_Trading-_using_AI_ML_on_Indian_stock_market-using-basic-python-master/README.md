# Zerodha_Live_Automate_Trading-_using_AI_ML_on_Indian_stock_market

#   Read file 'READ me' for all information of this Repositories      #

* This project is based on Online trading using Artificial Intelligence Machine leaning with python on Indian Stock Market, trading using live bots indicators screener and backtesters using rest api and websocket on zerodha kite.

* Zerodha    - Automated Python program for trading in Indian stock market.  

1. Getting Started with Zerodha ,Starting new project with zerodha .
2. BACKTESTIG_PROGRAM == What is Backtesting?
3. Historical Data Download Code for any stock of Stock Market.
4.Stock_Screener (GUPPY)== What is Stock_Screener ?
5.INDICATORS (ATR,RSI,SMA,EMA,Bollinger band ) on Historical_data 'SBI'
6. Live_Trading_BOTS==What is a Trading BOT ?
7.Trading Live BOT (1) == BUY-SELL BOT on RSI strategy
8.Trading Live BOT (2)==GUPPY strategy bot
9. Trading Live BOT (3) == automated bot of BUY-SELL bot on Guppy indicator 4 colours
10.Trading Live BOT (4) == Advance Multiple bot of buy/sell in one BOT with screener, backtestig
